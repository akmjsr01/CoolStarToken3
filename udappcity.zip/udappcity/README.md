# Decentralized Star Notary Service - Starter Code
Token Name = CoolStarToken
Token Symbol = CST
Token Address = 0x846c2453b8946cab8109920e21cace0599ffeb0b

